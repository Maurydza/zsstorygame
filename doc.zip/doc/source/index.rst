.. Przygody Bromka documentation master file, created by
   sphinx-quickstart on Wed Apr 15 18:06:53 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Przygody Bromka game documentation
=====================================

**Przygody Bromka** is a simple game about a tiny but mighty school based on a real place in Poland. 


.. toctree::
   :maxdepth: 2
   :caption: Classes:

   systems/Bot
   systems/Inventory
   systems/Item
   systems/ItemCarrier
   systems/KindaUselessThingy
   systems/MainMenu
   systems/NpcNeutral
   systems/NpcShopping
   systems/PersistentExactSceneOnlyObjects
   systems/PlayerFollow
   systems/PlayerMovement
   systems/PlayerRotation
   systems/PlayerTeleport
   systems/QuitMenu
   systems/Spawnpoint
   systems/SpeedWand
   systems/UniversalEventSystem
   systems/Weapon

