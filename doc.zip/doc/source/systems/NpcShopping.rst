NpcShopping
===========

This class describes the behavior of a neutral NPC that allows the player to interact, display dialogue, and purchase items (e.g. restoring HP) when the player is nearby.

Fields
-------

.. list-table::
   :header-rows: 1

   * - Field
     - Description
   * - public GameObject dialoguePanel
     - UI panel that displays the NPC dialogue.
   * - public Text dialogueText
     - UI text component used to render dialogue content.
   * - public string[] dialogueLines
     - Array of dialogue lines displayed sequentially.
   * - private int index
     - Index of the currently displayed dialogue line.
   * - private InputAction interraction
     - Input action responsible for interacting with the NPC (e.g. "E" key).
   * - private Coroutine typingCoroutine
     - Reference to the currently running typing coroutine.
   * - public GameObject BuyButton
     - Button used to trigger purchase action.
   * - public GameObject ExitButton
     - Button used to exit the dialogue.
   * - public float wordSpeed
     - Delay between each character when typing dialogue.
   * - public bool playerIsClose
     - Indicates whether the player is within interaction range.
   * - public GameObject Player
     - Reference to the player GameObject.
   * - public PlayerMovement playerMovement
     - Reference to the PlayerMovement script for accessing player stats.

Methods
--------

.. list-table::
    :header-rows: 1

    * - Method
      - Description
    * - private void Awake()
      - Initializes player reference and retrieves PlayerMovement component. Also initializes player money.
    * - void Start()
      - Initializes input action for interaction and sets initial player proximity state.
    * - void Update()
      - Handles interaction input, toggles dialogue panel, and controls dialogue typing logic. Also enables buttons when dialogue finishes.
    * - public void zeroExit()
      - Resets dialogue state, clears text, resets index, and hides the dialogue panel.
    * - public void Buy()
      - Handles purchase logic. Deducts money and restores player HP if sufficient funds are available.
    * - IEnumerator Typing()
      - Coroutine responsible for displaying dialogue text letter by letter with delay.
    * - private void OnTriggerEnter2D(Collider2D other)
      - Detects when the player enters NPC interaction range and enables interaction.
    * - private void OnTriggerExit2D(Collider2D other)
      - Detects when the player leaves NPC interaction range, disables interaction, and resets dialogue.