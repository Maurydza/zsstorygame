Bot
============

This class doesn't have any purpose, methods or fields.
